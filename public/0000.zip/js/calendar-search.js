let searchTimeout;
const ELEMENTS = {
    searchCustomerInput: document.getElementById('searchCustomer'),
    customerList: document.getElementById('customerList'),
    selectedCustomerId: document.getElementById('selectedCustomerId'),
    addCustomerForm: document.querySelector('.addCustomer'),
    resultsContainer: customerList.querySelector('.results-container'),
    newCustomerOption: customerList.querySelector('.new-customer-option')
};

// Yapılandırma sabitleri
const CONFIG = {
    searchDelay: 300,
    formFields: ['NewcustomerName', 'NewcustomerSurname', 'NewcustomerPhone', 'processStart', 'processEnd', 'doctorSelect']
};

// Arama işlemi
ELEMENTS.searchCustomerInput.addEventListener('input', function() {
    clearTimeout(searchTimeout);
    const searchTerm = this.value.trim();

    // Arama kutusunu temizleme
    if (searchTerm === '') {
        ELEMENTS.customerList.style.display = 'none';
        return;
    }

    // Debounce ile arama
    searchTimeout = setTimeout(() => {
        searchCustomers(searchTerm);
    }, 300);
});

// Müşteri arama fonksiyonu
async function searchCustomers(searchTerm) {
    try {
        ELEMENTS.resultsContainer.innerHTML = '';
        let matchFound = false;
        
        // AJAX çağrısı ile müşterileri getir
        const response = await fetch(`getCustomers?search=${encodeURIComponent(searchTerm)}`);
        const customers = await response.json();

        if (customers.length) {
            matchFound = true;
            const fragment = document.createDocumentFragment();
            
            customers.forEach(customer => {
                const item = createCustomerListItem(customer);
                fragment.appendChild(item);
            });
            
            ELEMENTS.resultsContainer.appendChild(fragment);
        }

        ELEMENTS.newCustomerOption.classList.toggle('d-none', matchFound);
        ELEMENTS.customerList.style.display = 'block';
    } catch (error) {
        console.error('Müşteri arama hatası:', error);
    }
}

// Müşteri liste öğesi oluşturma fonksiyonu
function createCustomerListItem(customer) {
    const item = document.createElement('button');
    item.type = 'button';
    item.className = 'dropdown-item d-flex align-items-center';
    item.innerHTML = `
        <i class="fal fa-user me-2"></i>
        <span>${customer.firstName} ${customer.lastName}</span>
    `;
    item.dataset.id = customer.id;
    item.dataset.name = `${customer.firstName} ${customer.lastName}`;
    
    item.addEventListener('click', () => selectCustomer(item.dataset.id, item.dataset.name));
    return item;
}

// Müşteri seçme işlemi
function selectCustomer(id, name) {
    ELEMENTS.selectedCustomerId.value = id;
    ELEMENTS.searchCustomerInput.value = name;
    ELEMENTS.customerList.style.display = 'none';
    ELEMENTS.addCustomerForm.style.display = 'none';
}

// Yeni müşteri ekleme butonu
document.querySelector('.new-customer-btn').addEventListener('click', () => {
    ELEMENTS.customerList.style.display = 'none';
    ELEMENTS.addCustomerForm.style.display = 'block';

    // Ad ve soyad alanlarını doldur
    const nameParts = ELEMENTS.searchCustomerInput.value.trim().split(' ');
    if (nameParts.length > 0) {
        document.getElementById('NewcustomerName').value = nameParts.slice(0, -1).join(' ');
        document.getElementById('NewcustomerSurname').value = nameParts.slice(-1)[0];

        document.getElementById('newCustomer').value = 1;
        
    }
});

// Yeni müşteri formunu kapatma
document.querySelector('.close-new-customer').addEventListener('click', () => {
    ELEMENTS.addCustomerForm.style.display = 'none';
    ELEMENTS.customerList.style.display = 'none';
    resetForm();
});

// Form reset fonksiyonu ekleyelim
function resetForm() {
    ELEMENTS.searchCustomerInput.value = '';
    ELEMENTS.selectedCustomerId.value = '';
    document.getElementById('newCustomer').value = '0';
    document.getElementById('NewcustomerName').value = '';
    document.getElementById('NewcustomerSurname').value = '';
    document.getElementById('NewcustomerPhone').value = '';
    document.getElementById('doctorSelect').value = '';
    document.getElementById('processStart').value = '';
    document.getElementById('processEnd').value = '';
    
    // İşlem container'ını varsayılan haline getir
    const processContainer = document.getElementById('processContainer');
    processContainer.innerHTML = `
        <div class="process-slot d-flex align-items-center gap-2 mb-2">
            <div class="input-group">
                <span class="input-group-text">
                    <i class="fal fa-tasks"></i>
                </span>
                <select class="custom-select custom-select-lg border-start-0" name="services_id[]">
                    @foreach ($services as $process)
                        <option value="{{ $process->id }}">{{ $process->category_name }} - {{ $process->name }}</option>
                    @endforeach
                </select>
            </div>
            <button type="button" id="addProcess" class="btn btn-primary btn-lg">
                <i class="fal fa-plus-circle me-2"></i>
            </button>
        </div>
    `;
}

// Form kontrolü geliştirmesi
function checkFormValidity() {
    const formData = {
        customerSelected: ELEMENTS.selectedCustomerId.value || isNewCustomerValid(),
        timeSelected: document.getElementById('processStart').value && 
                     document.getElementById('processEnd').value,
        doctorSelected: document.getElementById('doctorSelect').value
    };
    
    const isValid = Object.values(formData).every(Boolean);
    document.getElementById('addReservation').disabled = !isValid;
}

function isNewCustomerValid() {
    return document.getElementById('newCustomer').value === '1' && 
           CONFIG.formFields.slice(0, 3).every(field => 
               document.getElementById(field).value.trim() !== ''
           );
}

// Event listener'ları tek bir yerde toplayalım
function initializeEventListeners() {
    CONFIG.formFields.forEach(id => {
        document.getElementById(id).addEventListener('input', checkFormValidity);
    });
    
    // Dışarı tıklama kontrolü için event delegation kullanımı
    document.addEventListener('click', handleOutsideClick);
}

function handleOutsideClick(event) {
    const isOutsideClick = ![
        ELEMENTS.searchCustomerInput,
        ELEMENTS.customerList,
        ELEMENTS.addCustomerForm
    ].some(element => element.contains(event.target));
    
    if (isOutsideClick) {
        ELEMENTS.customerList.style.display = 'none';
    }
}

// Sayfa yüklendiğinde event listener'ları başlat
document.addEventListener('DOMContentLoaded', initializeEventListeners);